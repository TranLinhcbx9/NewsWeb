from logging import debug
from fastapi import FastAPI
from fastapi.params import Body, Query
import joblib
import uvicorn
import pickle
from text_preprocess import text_preprocess
from remove_stopwords import remove_stopwords
import os
import numpy as np
from pydantic import BaseModel


MODEL_PATH = "C:/Users/Linh/Desktop/NMCSDLL/API_AI/Text_classification-main/models"

nb_model = pickle.load(open(os.path.join(MODEL_PATH,"naive_bayes.pkl"), 'rb'))
app = FastAPI()

def preprocess(text):
    text = text_preprocess(text)
    text = remove_stopwords(text)
    return text

# @app.post("/classify_text")

# @app.get("/items/{text}")
# # async def read_item(item_id: int):
# #     return {"item_id": item_id}

# async def classify_text(text: str):
#     text = preprocess(text)
#     label = nb_model.predict([text])
#     result = {
#         'label': int(label[0])
#         }
#     return result

# from pydantic import BaseModel


class InputAIDto(BaseModel):
    text: str

@app.post("/items/")
async def classify_text(item: InputAIDto):
    text = preprocess(item.text)
    label = nb_model.predict([text])
    result = {
        'label': int(label[0])
        }
    return result